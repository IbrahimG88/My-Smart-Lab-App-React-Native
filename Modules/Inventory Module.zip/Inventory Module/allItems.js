
import React, { Component } from 'react';
import {AsyncStorage} from "react-native";



import { Container, Header, Content, List, ListItem, Text } from 'native-base';


class AllItems extends Component {
    constructor(props) {
        super(props);
        this.state = {
            allItems: [],
           
        }
    }

    componentDidMount() {
        let allItemsList = [];
        AsyncStorage.getItem('item').then((value) => {
            const restoredArray = JSON.parse(value);
            allItemsList.push(value);
            this.setState({'allItems': restoredArray });

        });

    }
    render(){
        return(
                <Container>
                    <Header />
                    <Content>
                        <List>
            {this.state.allItems.map((item)=>{
                return(
                            <ListItem>
                                <Text>{item}</Text>
                            </ListItem>)})}
                </List>
                    </Content>
                </Container>


        )
    }
}
export default AllItems;